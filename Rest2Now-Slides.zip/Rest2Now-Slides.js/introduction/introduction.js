$(function() {
	// Deck initialization
	$.deck('.slide');
	
	$('#demo-btn').click(function(){
		$('#demo-code').show();
	})
});

